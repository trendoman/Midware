<?php require_once( '../couch/cms.php' ); ?>
<cms:template title='Users' clonable='1'>

</cms:template>
<?php COUCH::invoke(); ?> 