<?php require_once( '../couch/cms.php' ); ?>
<cms:template title='About' order='2' clonable='0'>

    <cms:mosaic name='blocks' label='Blocks' body_class='_pb'>
        <cms:tile name='ab01' label='AB01' _pb_template='about/theme/AB01' _pb_height='350'>
            <cms:embed 'pb/about/embed/AB01.html' />
        </cms:tile>

        <cms:tile name='ab02' label='AB02' _pb_template='about/theme/AB02' _pb_height='350'>
            <cms:embed 'pb/about/embed/AB02.html' />
        </cms:tile>
    </cms:mosaic>

</cms:template>
<?php COUCH::invoke(); ?>
