<?php require_once( 'couch/cms.php' ); ?>

<?php COUCH::invoke(); ?>   