<?php require_once( '../couch/cms.php' ); ?>
<cms:template title='Covers' order='1' clonable='0'>

    <cms:mosaic name='blocks' label='Blocks' body_class='_pb'>
        <cms:tile name='cr01' label='CR01' _pb_template='covers/theme/CR01' _pb_height='350'>
            <cms:embed 'pb/covers/embed/CR01.html' />
        </cms:tile>

        <cms:tile name='cr02' label='CR02' _pb_template='covers/theme/CR02' _pb_height='350'>
            <cms:embed 'pb/covers/embed/CR02.html' />
        </cms:tile>
    </cms:mosaic>

</cms:template>
<?php COUCH::invoke(); ?>
