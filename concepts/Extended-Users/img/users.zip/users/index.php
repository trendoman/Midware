<?php require_once( '../couch/cms.php' ); ?>

<cms:template clonable='1' title='Users' hidden='1'>
    <!-- 
        If additional fields are required for users, they can be defined here in the usual manner.
    -->        

</cms:template>

<?php COUCH::invoke(); ?>